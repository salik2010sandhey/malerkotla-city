
export interface User {
  id: string;
  email: string;
  name: string;
}

export interface Business {
  id: string;
  owner_id: string;
  business_name: string;
  category: string;
  description: string;
  address: string;
  area: string;
  phone: string;
  whatsapp: string;
  email: string;
  opening_hours: string;
  map_link: string;
  images: string[];
  created_at: string;
  is_approved: boolean;
  is_featured: boolean;
  priority: number; // For manual ranking
  views: number;    // For popularity-based ranking
}
