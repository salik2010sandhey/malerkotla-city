import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://xfxwcjhlzaggphyvejne.supabase.co';
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhmeHdjamhsemFnZ3BoeXZlam5lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk5NTAxNzUsImV4cCI6MjA4NTUyNjE3NX0.rlrXMWDSqeSoLl_u_SwWkhLaUeYTdKk4COwZoNoq-uE";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
