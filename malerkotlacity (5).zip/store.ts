
import { User, Business } from './types';

const STORAGE_KEY = 'malerkotla_hub_data';

interface AppData {
  users: User[];
  businesses: Business[];
}

const getInitialData = (): AppData => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) return JSON.parse(stored);
  
  return {
    users: [],
    businesses: []
  };
};

export const appState = getInitialData();

export const syncData = () => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
};

export const resetData = () => {
    localStorage.removeItem(STORAGE_KEY);
    window.location.reload();
}
