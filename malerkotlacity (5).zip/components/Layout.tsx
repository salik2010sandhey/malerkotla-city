
import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../App';
import { Menu, X, Building2, LayoutDashboard, Search as SearchIcon, Info, Star, Home as HomeIcon, Plus, ShieldAlert } from 'lucide-react';

const SPECIAL_EMAIL = 'adminmalerkotla@gmail.com';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/');
    setIsMenuOpen(false);
  };

  const navLinks = [
    { name: 'Home', path: '/', icon: HomeIcon },
    { name: 'Search', path: '/directory', icon: SearchIcon },
    { name: 'Famous', path: '/famous', icon: Star },
    { name: 'About', path: '/about', icon: Info },
  ];

  const isActive = (path: string) => location.pathname === path;
  const isBusinessDetail = location.pathname.startsWith('/business/');
  const isAdmin = user?.email === SPECIAL_EMAIL;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[200] focus:px-6 focus:py-3 focus:bg-emerald-600 focus:text-white focus:rounded-xl focus:font-black focus:shadow-2xl transition-all"
      >
        Skip to main content
      </a>

      <header className="sticky top-0 z-[60] glass border-b border-slate-200/50" role="banner">
        <nav className="max-w-[1440px] mx-auto px-6 md:px-12 h-16 md:h-20 flex justify-between items-center" aria-label="Main Navigation">
          <Link to="/" className="flex items-center space-x-3 active-scale transition-transform focus-visible:ring-4 focus-visible:ring-emerald-500/20 focus-visible:outline-none rounded-xl" aria-label="Malerkotla City Home">
            <div className="bg-emerald-600 p-2 rounded-xl shadow-lg shadow-emerald-200" aria-hidden="true">
              <Building2 className="text-white" size={20} />
            </div>
            <span className="text-xl md:text-2xl font-black text-slate-900 tracking-tighter">
              Malerkotla<span className="text-emerald-600">City</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-10">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-bold tracking-wide transition-colors ${
                  isActive(link.path) ? 'text-emerald-600' : 'text-slate-500 hover:text-emerald-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <div className="h-6 w-px bg-slate-200" aria-hidden="true"></div>
            {user ? (
              <div className="flex items-center space-x-6">
                {isAdmin && (
                  <Link to="/admin" className="flex items-center space-x-2 text-sm font-bold text-rose-600 hover:text-rose-700">
                    <ShieldAlert size={18} />
                    <span>Admin Panel</span>
                  </Link>
                )}
                <Link to="/dashboard" className="flex items-center space-x-2 text-sm font-bold text-slate-700 hover:text-emerald-600">
                  <LayoutDashboard size={18} />
                  <span>Dashboard</span>
                </Link>
                <button onClick={handleLogout} className="text-sm font-bold text-rose-600 hover:text-rose-700">
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-6">
                <Link to="/login" className="text-sm font-bold text-slate-500 hover:text-emerald-600">Login</Link>
                <Link to="/register" className="px-7 py-3 bg-slate-900 text-white text-sm font-black rounded-xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-200">
                  Register
                </Link>
              </div>
            )}
          </div>

          <div className="md:hidden flex items-center space-x-3">
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="p-2 text-slate-900 active:bg-slate-100 rounded-full transition-colors"
            >
              <Menu size={24} />
            </button>
          </div>
        </nav>
      </header>

      <div className={`fixed inset-0 z-[100] transition-opacity duration-300 md:hidden ${isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
        <div className={`absolute top-0 right-0 h-full w-[80%] max-w-[320px] bg-white shadow-2xl transition-transform duration-300 ease-out ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="p-8 flex flex-col h-full">
            <div className="flex justify-between items-center mb-10">
              <span className="font-black text-xl tracking-tighter">MalerkotlaCity</span>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 bg-slate-50 rounded-full"><X size={20} /></button>
            </div>
            <div className="flex-grow space-y-2">
              {navLinks.map((link) => (
                <Link 
                  key={link.path} 
                  to={link.path} 
                  onClick={() => setIsMenuOpen(false)} 
                  className={`flex items-center space-x-4 p-4 rounded-2xl font-bold ${isActive(link.path) ? 'bg-emerald-50 text-emerald-600' : 'text-slate-600'}`}
                >
                  <link.icon size={20} />
                  <span>{link.name}</span>
                </Link>
              ))}
              {isAdmin && (
                <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-4 p-4 text-rose-600 font-bold"><ShieldAlert size={20} /><span>Admin Panel</span></Link>
              )}
              {user && (
                <Link to="/dashboard" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-4 p-4 text-slate-600 font-bold"><LayoutDashboard size={20} /><span>Dashboard</span></Link>
              )}
            </div>
            <div className="pt-8 border-t border-slate-100">
              {user ? (
                <button onClick={handleLogout} className="w-full py-4 text-rose-500 font-black uppercase text-xs tracking-widest">Sign Out</button>
              ) : (
                <Link to="/register" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-center w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-sm">Create Account</Link>
              )}
            </div>
          </div>
        </div>
      </div>

      <main id="main-content" className="flex-grow pb-24 md:pb-0">
        {children}
      </main>
    </div>
  );
};
