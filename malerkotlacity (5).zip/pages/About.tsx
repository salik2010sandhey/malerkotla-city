
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Heart, 
  History, 
  Utensils, 
  Building2, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Users 
} from 'lucide-react';
import { updateMeta } from '../utils/seo';

const About: React.FC = () => {
  useEffect(() => {
    updateMeta(
      "About Malerkotla – Culture, Harmony & City Life",
      "Learn about the rich history, communal harmony, and vibrant culture of Malerkotla city in Punjab. Discover our digital mission."
    );
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://www.theislamicheritage.com/uploads/submission_images/281_Mubarak_Manzil_Palace%2C_Malerkotla_01.jpg" 
            className="w-full h-full object-cover brightness-[0.3]" 
            alt="Mubarak Manzil Palace heritage architecture in Malerkotla"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white/10"></div>
        </div>
        <div className="relative text-center px-4 max-w-4xl animate-in fade-in zoom-in duration-700">
          <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tight">
            About Malerkotla City
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 font-light max-w-2xl mx-auto leading-relaxed">
            A Historic City of Culture, Harmony, and Local Enterprise in the Heart of Punjab.
          </p>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div>
            <div className="flex items-center space-x-3 text-emerald-600 font-black uppercase tracking-widest text-xs mb-6">
              <Sparkles size={18} />
              <span>A Living Heritage</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-8 leading-tight tracking-tight">
              A Symbol of Unity in <br /> Malerkotla, Punjab
            </h2>
            <div className="space-y-6 text-slate-600 text-lg leading-relaxed font-light">
              <p>
                Located in the Sangrur district of Punjab, Malerkotla is more than just a city; it is a global emblem of peace and brotherhood. For centuries, this historic town has maintained a unique legacy of communal harmony.
              </p>
              <p>
                Known for its rich "Ganga-Jamuni Tehzeeb," Malerkotla is a place where different faiths and traditions blend seamlessly. From the historic <strong>"Haa Da Naara"</strong> to its vibrant markets, the city celebrates its identity through mutual respect and shared heritage.
              </p>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-[3rem] overflow-hidden shadow-2xl shadow-slate-300">
              <img 
                src="https://nidhi.tourism.gov.in/api/FileUpload?FilePath=null%2Fattraction_details%2Fgallery%2F638002467112517388.jpg" 
                className="w-full h-full object-cover" 
                alt="Traditional lifestyle and markets in Malerkotla"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 bg-emerald-600 p-10 rounded-[2.5rem] shadow-xl text-white max-w-xs hidden md:block">
              <Heart className="mb-4" size={40} />
              <h3 className="text-xl font-bold mb-2">Peace & Harmony</h3>
              <p className="text-emerald-100 text-sm font-medium">Centuries of social stability and communal brotherhood in Malerkotla city.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-black text-slate-900 mb-4">The Essence of Malerkotla</h2>
            <p className="text-slate-500 text-lg max-w-2xl mx-auto">Explore the history and local life that make Malerkotla a special city to live and do business.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-white p-12 rounded-[3rem] shadow-xl shadow-slate-200/50 border border-slate-100 transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-8">
                <History size={32} />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-4">Historic Legacy</h3>
              <p className="text-slate-500 leading-relaxed font-light">Founded in 1454, Malerkotla boasts a fascinating history that is revered across India for its stance on justice.</p>
            </div>

            <div className="bg-white p-12 rounded-[3rem] shadow-xl shadow-slate-200/50 border border-slate-100 transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mb-8">
                <Utensils size={32} />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-4">City Culture</h3>
              <p className="text-slate-500 leading-relaxed font-light">Famous for its unique cuisine, metal-works, and vibrant local markets like Kila Market offering designer wear.</p>
            </div>

            <div className="bg-white p-12 rounded-[3rem] shadow-xl shadow-slate-200/50 border border-slate-100 transition-all hover:-translate-y-2">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-8">
                <Building2 size={32} />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-4">Enterprise Hub</h3>
              <p className="text-slate-500 leading-relaxed font-light">A major center for agricultural machinery and textiles in Punjab, supported by thousands of local experts.</p>
            </div>
          </div>
        </div>
      </section>

      {/* The Platform Purpose */}
      <section className="py-32 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[4rem] p-12 md:p-24 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-600 rounded-full -mr-48 -mt-48 opacity-20 blur-3xl"></div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-black mb-8 leading-tight tracking-tight">
                Our Digital Vision <br /> for Malerkotla City
              </h2>
              <div className="space-y-6 text-slate-300 text-lg font-light leading-relaxed">
                <p>
                  MalerkotlaCity was created to build a modern digital bridge for our city's incredible local businesses and service providers.
                </p>
                <p>
                  We believe every Malerkotla shop deserves a professional online presence. Our mission is to:
                </p>
                <ul className="space-y-4 pt-4">
                  <li className="flex items-center space-x-3">
                    <ShieldCheck className="text-emerald-400" size={20} />
                    <span>Provide verified digital IDs for Malerkotla businesses.</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Users className="text-emerald-400" size={20} />
                    <span>Help citizens discover local experts in Malerkotla Punjab.</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Heart className="text-emerald-400" size={20} />
                    <span>Strengthen the local economy by promoting city markets.</span>
                  </li>
                </ul>
              </div>
            </div>
            <div className="flex flex-col space-y-8">
              <div className="bg-white/10 backdrop-blur-md p-10 rounded-[2.5rem] border border-white/10">
                <h3 className="text-2xl font-bold mb-4">Own a Business in Malerkotla?</h3>
                <p className="text-slate-300 mb-8 font-light">Join the hub today and let the city discover your services. It's fast and free.</p>
                <Link to="/register" className="inline-flex items-center justify-center w-full py-5 bg-emerald-500 hover:bg-emerald-600 text-white font-black rounded-2xl transition-all shadow-xl shadow-emerald-500/20 group">
                  List Your Business Now
                  <ArrowRight className="ml-3 group-hover:translate-x-2 transition-transform" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
