import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../supabase';
import { Business } from '../types';
import { 
  Search, 
  MapPin, 
  Filter, 
  ChevronRight, 
  Loader2, 
  Grid, 
  List, 
  Map as MapIcon,
  X,
  ChevronDown,
  Phone,
  MessageSquare,
  Award,
  SearchX
} from 'lucide-react';
import L from 'leaflet';
import { updateMeta } from '../utils/seo';

type ViewMode = 'GRID' | 'LIST' | 'MAP';

const BusinessDirectory: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [availableCategories, setAvailableCategories] = useState<string[]>([]);
  const [availableAreas, setAvailableAreas] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState<string>(searchParams.get('category') || 'All');
  const [selectedArea, setSelectedArea] = useState<string>('All');
  const [viewMode, setViewMode] = useState<ViewMode>('GRID');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);
  const markersLayer = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    updateMeta(
      "Search Malerkotla Business Directory",
      "Find local experts in Malerkotla Punjab. Filter by category, area, or name to find verified shops and services."
    );
  }, []);

  useEffect(() => {
    const fetchOptions = async () => {
      const { data } = await supabase.from('businesses').select('category, area');
      if (data) {
        // Fix: Explicitly cast the result to string[] to satisfy the state setter's type requirements
        setAvailableCategories(Array.from(new Set(data.map(b => (b as any).category))).filter(Boolean).map(c => String(c)).sort());
        setAvailableAreas(Array.from(new Set(data.map(b => (b as any).area))).filter(Boolean).map(a => String(a)).sort());
      }
    };
    fetchOptions();
  }, []);

  useEffect(() => {
    const fetchBusinesses = async () => {
      setLoading(true);
      let query = supabase.from('businesses').select('*').order('priority', { ascending: false }).order('views', { ascending: false });
      if (selectedCategory !== 'All') query = query.eq('category', selectedCategory);
      if (selectedArea !== 'All') query = query.eq('area', selectedArea);
      if (search) query = query.ilike('business_name', `%${search}%`);

      const { data } = await query;
      // Fix: Cast data to Business[] to ensure type safety with state setter
      if (data) setBusinesses(data as Business[]);
      setLoading(false);
    };
    fetchBusinesses();
  }, [search, selectedCategory, selectedArea]);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 md:py-20">
      {/* Search Header */}
      <div className="mb-16 space-y-12">
        <header className="max-w-3xl">
          <h1 className="text-4xl md:text-7xl font-black text-slate-900 tracking-tighter mb-6">Directory</h1>
          <p className="text-slate-500 text-lg md:text-2xl font-light">Explore verified shops and local experts in Malerkotla city.</p>
        </header>

        <div className="flex flex-col lg:flex-row gap-6">
          <div className="relative flex-grow">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
            <input 
              type="text" 
              placeholder="Search business name..." 
              className="w-full pl-16 pr-6 py-6 bg-white border border-slate-200 rounded-[2rem] text-xl font-bold outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all shadow-xl shadow-slate-100"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-4">
            <select 
              className="px-8 py-6 bg-white border border-slate-200 rounded-[2rem] text-sm font-black uppercase tracking-widest outline-none shadow-xl shadow-slate-100 cursor-pointer hidden md:block"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="All">All Categories</option>
              {availableCategories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button 
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className="lg:hidden flex-1 px-8 py-6 bg-slate-900 text-white rounded-[2rem] font-black uppercase text-xs tracking-widest flex items-center justify-center gap-3"
            >
              <Filter size={20} />
              Filters
            </button>
          </div>
        </div>

        {/* Mobile Filters UI */}
        {isFilterOpen && (
          <div className="lg:hidden bg-slate-50 p-10 rounded-[3rem] border border-slate-100 space-y-8 animate-in slide-in-from-top-4 duration-300">
            <div className="grid grid-cols-1 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">By Category</label>
                <select className="w-full p-5 bg-white border border-slate-200 rounded-2xl text-sm font-bold" value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}>
                  <option value="All">All Categories</option>
                  {availableCategories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">By Locality</label>
                <select className="w-full p-5 bg-white border border-slate-200 rounded-2xl text-sm font-bold" value={selectedArea} onChange={e => setSelectedArea(e.target.value)}>
                  <option value="All">All Areas</option>
                  {availableAreas.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
            </div>
            <button onClick={() => {setSearch(''); setSelectedCategory('All'); setSelectedArea('All'); setIsFilterOpen(false);}} className="w-full py-5 text-rose-500 font-black uppercase text-[10px] tracking-widest bg-rose-50 rounded-2xl">Reset All</button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-16">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block lg:col-span-1 space-y-12">
          <div className="bg-slate-50 p-10 rounded-[3rem] border border-slate-100 sticky top-32 space-y-10">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center">
              <Filter size={16} className="mr-3" /> Refine Results
            </h3>
            <div className="space-y-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-1">Category</label>
                <select className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold shadow-sm" value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}>
                  <option value="All">All Categories</option>
                  {availableCategories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-1">Area</label>
                <select className="w-full p-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold shadow-sm" value={selectedArea} onChange={e => setSelectedArea(e.target.value)}>
                  <option value="All">All Areas</option>
                  {availableAreas.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
              <button onClick={() => {setSearch(''); setSelectedCategory('All'); setSelectedArea('All');}} className="w-full py-4 text-emerald-600 font-black uppercase text-[10px] tracking-widest bg-emerald-50 rounded-2xl hover:bg-emerald-600 hover:text-white transition-all">Clear Filters</button>
            </div>
          </div>
        </aside>

        {/* Results Grid */}
        <div className="lg:col-span-3">
          <div className="mb-10 flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              {loading ? 'Searching...' : `Found ${businesses.length} ${businesses.length === 1 ? 'Business' : 'Businesses'}`}
            </span>
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button onClick={() => setViewMode('GRID')} className={`p-2 rounded-lg transition-all ${viewMode === 'GRID' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}><Grid size={18} /></button>
              <button onClick={() => setViewMode('LIST')} className={`p-2 rounded-lg transition-all ${viewMode === 'LIST' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}><List size={18} /></button>
            </div>
          </div>

          {loading ? (
            <div className="py-40 flex justify-center"><Loader2 className="animate-spin text-emerald-600" size={64} /></div>
          ) : businesses.length > 0 ? (
            <div className={viewMode === 'GRID' ? "grid grid-cols-1 md:grid-cols-2 gap-10" : "space-y-8"}>
              {businesses.map(biz => (
                <article key={biz.id} className={`group bg-white border border-slate-100 rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 flex flex-col h-full ${viewMode === 'LIST' ? 'md:flex-row' : ''}`}>
                  <Link to={`/business/${biz.id}`} className={`relative overflow-hidden block ${viewMode === 'LIST' ? 'md:w-1/3 h-48 md:h-full' : 'aspect-[16/11]'}`}>
                    <img src={biz.images[0] || 'https://via.placeholder.com/800x600?text=No+Image'} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={biz.business_name} />
                    <div className="absolute top-6 left-6">
                      <span className="px-3 py-1 bg-white/95 backdrop-blur-md rounded-xl text-[8px] font-black text-slate-900 uppercase tracking-widest shadow-sm">
                        {biz.category}
                      </span>
                    </div>
                  </Link>
                  <div className={`p-10 flex flex-col justify-between flex-grow ${viewMode === 'LIST' ? 'md:w-2/3' : ''}`}>
                    <div>
                      <Link to={`/business/${biz.id}`}>
                        <h3 className="text-2xl font-black text-slate-900 group-hover:text-emerald-600 transition-colors tracking-tight line-clamp-1 mb-2">{biz.business_name}</h3>
                      </Link>
                      <div className="flex items-center text-slate-400 font-bold text-xs mb-6">
                        <MapPin size={16} className="mr-1.5 text-emerald-500" />
                        {biz.area}, Malerkotla
                      </div>
                      <p className="text-slate-500 text-sm line-clamp-2 font-light mb-8">{biz.description || "Trusted business in Malerkotla Punjab."}</p>
                    </div>
                    <div className="pt-8 border-t border-slate-50 flex gap-3">
                      <a href={`tel:${biz.phone}`} className="flex-1 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-black uppercase text-[10px] tracking-widest active-scale">Call</a>
                      <a href={`https://wa.me/${biz.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex-1 h-14 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-2xl flex items-center justify-center font-black uppercase text-[10px] tracking-widest active-scale">WhatsApp</a>
                      <Link to={`/business/${biz.id}`} className="w-14 h-14 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all"><ChevronRight size={20} /></Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="bg-slate-50 p-20 rounded-[4rem] text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-sm">
                <SearchX size={32} className="text-slate-300" />
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-4">No results found</h3>
              <p className="text-slate-500 text-lg mb-10 max-sm mx-auto font-light">Try adjusting your filters or search terms for Malerkotla experts.</p>
              <button onClick={() => {setSearch(''); setSelectedCategory('All'); setSelectedArea('All');}} className="px-10 py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-xl active-scale">Clear All Search</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BusinessDirectory;