
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../App';
import { supabase } from '../supabase';
import { Building2, MapPin, Phone, MessageSquare, Clock, Globe, CheckCircle2, Loader2, ArrowRight, Upload, X, AlertCircle, Tag } from 'lucide-react';

const SPECIAL_EMAIL = 'adminmalerkotla@gmail.com';

const AddBusiness = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [checkingExisting, setCheckingExisting] = useState(true);
  const [alreadyHasBusiness, setAlreadyHasBusiness] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    business_name: '',
    category: '',
    description: '',
    address: '',
    area: '',
    phone: '',
    whatsapp: '',
    opening_hours: '9:00 AM - 8:00 PM',
    map_link: ''
  });

  useEffect(() => {
    const checkExistingBusiness = async () => {
      if (!user) return;
      
      if (user.email === SPECIAL_EMAIL) {
        setCheckingExisting(false);
        return;
      }

      const { data } = await supabase
        .from('businesses')
        .select('id')
        .eq('owner_id', user.id)
        .limit(1);

      if (data && data.length > 0) {
        setAlreadyHasBusiness(true);
      }
      setCheckingExisting(false);
    };

    checkExistingBusiness();
  }, [user]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = (Array.from(e.target.files) as File[]).slice(0, 5 - files.length);
      const newPreviews = newFiles.map(file => URL.createObjectURL(file));
      setFiles(prev => [...prev, ...newFiles]);
      setPreviews(prev => [...prev, ...newPreviews]);
    }
  };

  const removeImage = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setPreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (files.length === 0) {
      alert("Please upload at least one image.");
      return;
    }

    if (!formData.area || !formData.address) {
      alert("Please provide location details.");
      return;
    }

    setLoading(true);

    try {
      // Auto-generate map search link
      const searchQuery = `${formData.business_name}, ${formData.address}, ${formData.area}, Malerkotla, Punjab`;
      const generatedMapLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(searchQuery)}`;

      const uploadedUrls: string[] = [];
      for (const file of files) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `business-images/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('business-images')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('business-images')
          .getPublicUrl(filePath);
        
        uploadedUrls.push(publicUrl);
      }

      const { error: businessError } = await supabase
        .from('businesses')
        .insert({
          owner_id: user.id,
          business_name: formData.business_name,
          category: formData.category,
          description: formData.description,
          address: formData.address,
          area: formData.area,
          phone: formData.phone,
          whatsapp: formData.whatsapp,
          email: user.email,
          opening_hours: formData.opening_hours,
          images: uploadedUrls,
          map_link: generatedMapLink // Use auto-generated link
        });

      if (businessError) throw businessError;
      setSuccess(true);
    } catch (error: any) {
      alert(error.message || "Failed to submit business.");
    } finally {
      setLoading(false);
    }
  };

  if (checkingExisting) {
    return (
      <div className="min-h-screen flex items-center justify-center" aria-live="polite">
        <Loader2 className="animate-spin text-emerald-600" size={48} aria-hidden="true" />
      </div>
    );
  }

  if (alreadyHasBusiness) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-32 text-center animate-in fade-in duration-500" aria-live="polite">
        <div className="w-24 h-24 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center mx-auto mb-8" aria-hidden="true">
          <AlertCircle size={48} />
        </div>
        <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">One Business Only</h2>
        <p className="text-slate-500 text-xl mb-12 max-w-lg mx-auto leading-relaxed">
          You have already registered a business. We only allow one business per user to maintain directory quality.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-6">
          <Link to="/dashboard" className="px-12 py-5 bg-slate-900 text-white font-black rounded-2xl hover:bg-slate-800 transition-all shadow-xl focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-slate-900/30">
            Go to My Dashboard
          </Link>
          <Link to="/directory" className="px-12 py-5 bg-slate-100 text-slate-700 font-black rounded-2xl hover:bg-slate-200 transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-slate-200/30">
            Browse Others
          </Link>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-32 text-center animate-in zoom-in duration-500" aria-live="polite">
        <div className="w-32 h-32 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-12" aria-hidden="true">
          <CheckCircle2 size={64} />
        </div>
        <h2 className="text-5xl font-black text-slate-900 mb-6 tracking-tight">Listing is Live!</h2>
        <p className="text-slate-500 text-xl mb-12 max-w-lg mx-auto leading-relaxed">
          Congratulations! <strong>"{formData.business_name}"</strong> has been successfully listed and is now visible to everyone in Malerkotla.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-6">
          <button onClick={() => navigate('/directory')} className="px-12 py-5 bg-emerald-600 text-white font-black rounded-2xl hover:bg-emerald-700 transition-all shadow-xl focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-500/30">
            View Directory
          </button>
          <button onClick={() => navigate('/dashboard')} className="px-12 py-5 bg-slate-100 text-slate-700 font-black rounded-2xl hover:bg-slate-200 transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-slate-200/30">
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-20">
      <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 p-10 md:p-20 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-50 rounded-full -mr-32 -mt-32 opacity-50" aria-hidden="true"></div>
        
        <header className="relative z-10 mb-16">
          <h2 className="text-5xl font-black text-slate-900 mb-4 tracking-tight">List Your Business</h2>
          <p className="text-slate-500 text-xl font-light">Join Malerkotla's digital hub. One listing per owner.</p>
        </header>

        <form onSubmit={handleSubmit} className="relative z-10 space-y-12" aria-busy={loading}>
          {/* Image Upload */}
          <fieldset className="space-y-4">
            <legend className="text-xs font-black text-slate-400 uppercase tracking-widest block ml-1 mb-2">Gallery (1-5 Photos)</legend>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-6">
              {previews.map((preview, index) => (
                <div key={index} className="relative aspect-square rounded-2xl overflow-hidden border border-slate-200 shadow-sm group">
                  <img src={preview} className="w-full h-full object-cover" alt={`Preview ${index + 1}`} />
                  <button 
                    type="button" 
                    onClick={() => removeImage(index)} 
                    className="absolute top-2 right-2 p-1.5 bg-rose-600 text-white rounded-full opacity-100 md:opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
              {files.length < 5 && (
                <label className="aspect-square border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center bg-slate-50 hover:bg-emerald-50 hover:border-emerald-300 transition-all cursor-pointer group">
                  <input type="file" accept="image/*" multiple onChange={handleImageChange} className="sr-only" />
                  <Upload className="text-slate-300 group-hover:text-emerald-500 mb-3" size={32} />
                  <span className="text-[10px] font-black text-slate-400 uppercase group-hover:text-emerald-600">Add Photo</span>
                </label>
              )}
            </div>
          </fieldset>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-2">
              <label htmlFor="biz-name" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Business Name</label>
              <div className="relative">
                <Building2 className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="biz-name" required className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.business_name} onChange={e => setFormData({...formData, business_name: e.target.value})} placeholder="e.g. Malerkotla Sweets" />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="biz-category" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Category</label>
              <div className="relative">
                <Tag className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="biz-category" required className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} placeholder="e.g. Food, Textiles" />
              </div>
            </div>

            <div className="md:col-span-2 space-y-2">
              <label htmlFor="biz-desc" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">About the Business</label>
              <textarea id="biz-desc" required className="w-full px-8 py-6 bg-slate-50 border border-slate-200 rounded-[2rem] outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-medium min-h-[150px]" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Describe your services..." />
            </div>

            <div className="space-y-2">
              <label htmlFor="biz-phone" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="biz-phone" required type="tel" className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="+91 98XXX XXXXX" />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="biz-whatsapp" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">WhatsApp No.</label>
              <div className="relative">
                <MessageSquare className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="biz-whatsapp" required type="tel" className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.whatsapp} onChange={e => setFormData({...formData, whatsapp: e.target.value})} placeholder="+91 98XXX XXXXX" />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="biz-hours" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Opening Hours</label>
              <div className="relative">
                <Clock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="biz-hours" required className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.opening_hours} onChange={e => setFormData({...formData, opening_hours: e.target.value})} placeholder="Mon - Sat: 9am - 8pm" />
              </div>
            </div>

            {/* Simplified Location Section */}
            <div className="md:col-span-2 space-y-8 p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center">
                <MapPin className="mr-2 text-emerald-600" size={18} /> Location Details
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-2">
                  <label htmlFor="biz-area" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Area / Locality</label>
                  <input id="biz-area" required className="w-full px-6 py-5 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.area} onChange={e => setFormData({...formData, area: e.target.value})} placeholder="e.g. Kila Market, Satta Bazaar" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="biz-address" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Full Address</label>
                  <textarea id="biz-address" required className="w-full px-6 py-4 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold min-h-[60px]" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} placeholder="Shop No., Street, Nearby Landmark (No map link needed)" />
                </div>
              </div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center italic">Maps search link will be generated automatically from your address.</p>
            </div>
          </div>

          <button type="submit" disabled={loading} className="w-full py-6 bg-emerald-600 text-white font-black text-xl rounded-3xl hover:bg-emerald-700 transition-all flex items-center justify-center space-x-3 shadow-2xl shadow-emerald-900/20 disabled:opacity-70 group">
            {loading ? <Loader2 className="animate-spin" size={24} /> : (
              <>
                <span>Publish Listing Now</span>
                <ArrowRight className="group-hover:translate-x-2 transition-transform" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddBusiness;
