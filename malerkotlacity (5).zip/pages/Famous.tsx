
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Zap, 
  Heart, 
  Utensils, 
  ShoppingBag, 
  Scissors, 
  Hammer, 
  ArrowRight, 
  Star,
  CheckCircle2,
  Building2
} from 'lucide-react';
import { updateMeta } from '../utils/seo';

const Famous: React.FC = () => {
  useEffect(() => {
    updateMeta(
      "Famous in Malerkotla – Markets, Food & Culture",
      "Explore what makes Malerkotla famous. Discover historic markets, traditional Punjabi food, expert tailoring, and industrial ironworks."
    );
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://i.ytimg.com/vi/LLBaqGyPcss/maxresdefault.jpg" 
            className="w-full h-full object-cover brightness-[0.25]" 
            alt="Vibrant textiles and culture in Malerkotla, Punjab"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white/10 to-transparent"></div>
        </div>
        <div className="relative text-center px-4 max-w-5xl animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="flex items-center justify-center space-x-2 text-emerald-400 font-black uppercase tracking-[0.3em] text-xs mb-6">
            <Star size={16} fill="currentColor" />
            <span>The Pride of Punjab</span>
            <Star size={16} fill="currentColor" />
          </div>
          <h1 className="text-6xl md:text-8xl font-black text-white mb-8 tracking-tighter leading-none">
            Famous In <br /> <span className="text-emerald-500">Malerkotla</span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
            From world-renowned communal harmony to the intricate art of Punjabi suits, discover why Malerkotla city is legendary.
          </p>
        </div>
      </section>

      {/* Legacy Section */}
      <section className="py-32 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[4rem] p-12 md:p-20 text-white relative overflow-hidden flex flex-col md:flex-row items-center gap-16">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500 rounded-full -mr-32 -mt-32 opacity-10 blur-3xl"></div>
          <div className="w-full md:w-1/2">
            <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-2xl flex items-center justify-center mb-8 border border-emerald-500/20">
              <Heart size={32} />
            </div>
            <h2 className="text-4xl md:text-5xl font-black mb-8 leading-tight tracking-tight">
              A Legacy of <span className="text-emerald-400">Harmony</span>
            </h2>
            <p className="text-slate-400 text-xl font-light leading-relaxed mb-8">
              Malerkotla is world-famous for its record of peace. The historic <strong>"Haa Da Naara"</strong> remains a foundational pillar of Malerkotla city's identity.
            </p>
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-white/5 rounded-xl border border-white/10 text-emerald-400">
                <CheckCircle2 size={24} />
              </div>
              <p className="font-bold text-slate-200">A global symbol of communal unity in Punjab.</p>
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <img 
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQj1Mgf2ndk-NEbqNFK6n10yEPg1ColA0BoFg&s" 
              className="rounded-[3rem] shadow-2xl grayscale hover:grayscale-0 transition-all duration-700" 
              alt="Brotherhood and identity in Malerkotla city" 
            />
          </div>
        </div>
      </section>

      {/* Famous Categories */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-24">
            <h2 className="text-5xl font-black text-slate-900 mb-6 tracking-tight">Famous Malerkotla Highlights</h2>
            <p className="text-slate-500 text-xl max-w-2xl mx-auto font-light">The craftsmanship and flavors that define Malerkotla's local economy.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <article className="group bg-white p-12 rounded-[3.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 hover:border-emerald-200 transition-all">
              <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform">
                <Utensils size={32} />
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-6">Malerkotla Food</h3>
              <p className="text-slate-500 text-lg leading-relaxed font-light mb-8">
                Famous for traditional Punjabi flavors, Malerkotla's street food and local sweets are legendary across the state.
              </p>
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Local Delicacies</span>
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Agricultural Produce</span>
              </div>
            </article>

            <article className="group bg-white p-12 rounded-[3.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 hover:border-emerald-200 transition-all">
              <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform">
                <ShoppingBag size={32} />
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-6">Historic Markets</h3>
              <p className="text-slate-500 text-lg leading-relaxed font-light mb-8">
                The <strong>Kila Market</strong> and Satta Bazaar are the heart of Malerkotla trade, bustling with local life.
              </p>
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Kila Market Shops</span>
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Local Trade</span>
              </div>
            </article>

            <article className="group bg-white p-12 rounded-[3.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 hover:border-emerald-200 transition-all">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform">
                <Scissors size={32} />
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-6">Punjabi Suit Tailoring</h3>
              <p className="text-slate-500 text-lg leading-relaxed font-light mb-8">
                Malerkotla is famous for its intricate suit tailoring and embroidery, with designer boutiques serving customers statewide.
              </p>
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Designer Boutiques</span>
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Expert Embroidery</span>
              </div>
            </article>

            <article className="group bg-white p-12 rounded-[3.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 hover:border-emerald-200 transition-all">
              <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform">
                <Hammer size={32} />
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-6">Iron & Engineering</h3>
              <p className="text-slate-500 text-lg leading-relaxed font-light mb-8">
                A powerhouse for agricultural machinery, Malerkotla industry supports farmers with robust engineering.
              </p>
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Iron Works</span>
                <span className="px-4 py-1.5 bg-slate-50 text-slate-500 text-[10px] font-black uppercase rounded-full border border-slate-100">Agri-Machinery</span>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-7xl font-black text-slate-900 mb-10 tracking-tight leading-none">
            Experience the Best of <br /> Malerkotla City
          </h2>
          <p className="text-slate-500 text-2xl font-light mb-16 leading-relaxed">
            The heart of our city lives in its markets and local shops. Explore the verified directory.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Link to="/directory" className="inline-flex items-center justify-center px-12 py-6 bg-slate-900 text-white font-black text-xl rounded-3xl hover:bg-slate-800 transition-all shadow-2xl shadow-slate-400 group">
              Explore Local Shops
              <ArrowRight className="ml-3 group-hover:translate-x-2 transition-transform" />
            </Link>
            <Link to="/about" className="inline-flex items-center justify-center px-12 py-6 bg-slate-50 text-slate-900 font-black text-xl rounded-3xl hover:bg-slate-100 transition-all border border-slate-200">
              <Building2 className="mr-3 text-emerald-600" />
              City History
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Famous;
