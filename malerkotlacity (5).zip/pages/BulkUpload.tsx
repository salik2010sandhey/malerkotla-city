
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../supabase';
import { useAuth } from '../App';
import { Upload, FileText, CheckCircle, AlertCircle, Loader2, Download, ArrowLeft, X } from 'lucide-react';

const BulkUpload = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<{ type: 'success' | 'error'; msg: string }[]>([]);
  const [stats, setStats] = useState({ success: 0, error: 0 });

  const parseCSV = (text: string) => {
    const rows: string[][] = [];
    let currentRow: string[] = [];
    let currentField = '';
    let inQuotes = false;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const nextChar = text[i + 1];

      if (char === '"') {
        if (inQuotes && nextChar === '"') {
          currentField += '"';
          i++; 
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        currentRow.push(currentField.trim());
        currentField = '';
      } else if ((char === '\n' || char === '\r') && !inQuotes) {
        if (currentField || currentRow.length > 0) {
            currentRow.push(currentField.trim());
            rows.push(currentRow);
        }
        currentRow = [];
        currentField = '';
        if (char === '\r' && nextChar === '\n') i++;
      } else {
        currentField += char;
      }
    }
    if (currentField || currentRow.length > 0) {
      currentRow.push(currentField.trim());
      rows.push(currentRow);
    }
    return rows;
  };

  const handleDownloadTemplate = () => {
    const headers = ['business_name', 'category', 'description', 'address', 'area', 'phone', 'whatsapp', 'opening_hours', 'image_url'];
    const example = ['"My Shop"', '"Retail"', '"Best shop in town"', '"Shop 1, Main St"', '"Kila Market"', '"9876543210"', '"9876543210"', '"9 AM - 8 PM"', '"https://example.com/image.jpg"'];
    const csvContent = [headers.join(','), example.join(',')].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'business_upload_template.csv';
    a.click();
  };

  const processFile = async () => {
    if (!file || !user) return;
    setLoading(true);
    setLogs([]);
    setStats({ success: 0, error: 0 });

    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target?.result as string;
      if (!text) return;

      const rows = parseCSV(text);
      if (rows.length < 2) {
        setLogs(prev => [...prev, { type: 'error', msg: 'CSV file is empty or missing headers.' }]);
        setLoading(false);
        return;
      }

      const headers = rows[0].map(h => h.toLowerCase().replace(/[\s_]+/g, '_'));
      // Basic mapping
      const getIdx = (name: string) => headers.indexOf(name);
      
      let successCount = 0;
      let errorCount = 0;

      // Skip header row
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (row.length === 0 || (row.length === 1 && !row[0])) continue;

        const getValue = (field: string) => {
          const idx = getIdx(field);
          return idx !== -1 ? row[idx] : '';
        };

        const businessName = getValue('business_name');
        const address = getValue('address');
        const area = getValue('area');

        if (!businessName || !address || !area) {
          setLogs(prev => [...prev, { type: 'error', msg: `Row ${i + 1}: Missing required fields (Name, Address, or Area).` }]);
          errorCount++;
          continue;
        }

        const searchQuery = `${businessName}, ${address}, ${area}, Malerkotla, Punjab`;
        const mapLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(searchQuery)}`;
        const imageUrl = getValue('image_url');
        const images = imageUrl ? [imageUrl] : [];

        try {
          const { error } = await supabase.from('businesses').insert({
            owner_id: user.id,
            business_name: businessName,
            category: getValue('category'),
            description: getValue('description'),
            address: address,
            area: area,
            phone: getValue('phone'),
            whatsapp: getValue('whatsapp'),
            email: user.email,
            opening_hours: getValue('opening_hours'),
            images: images,
            map_link: mapLink
          });

          if (error) throw error;
          
          setLogs(prev => [...prev, { type: 'success', msg: `Row ${i + 1}: "${businessName}" added successfully.` }]);
          successCount++;
        } catch (err: any) {
          setLogs(prev => [...prev, { type: 'error', msg: `Row ${i + 1}: Failed - ${err.message}` }]);
          errorCount++;
        }
      }

      setStats({ success: successCount, error: errorCount });
      setLoading(false);
    };

    reader.readAsText(file);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 md:py-20">
      <div className="mb-8">
        <button onClick={() => navigate('/dashboard')} className="flex items-center text-slate-500 hover:text-slate-900 transition-colors mb-4">
          <ArrowLeft size={20} className="mr-2" /> Back to Dashboard
        </button>
        <h1 className="text-4xl font-black text-slate-900 mb-2 tracking-tight">Bulk Upload Businesses</h1>
        <p className="text-slate-500">Upload multiple listings via CSV file.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-slate-100">
            <h3 className="text-lg font-bold text-slate-900 mb-4">1. Prepare your CSV</h3>
            <p className="text-slate-500 text-sm mb-6">
              Download the template to see the required format. Required columns: business_name, address, area.
            </p>
            <button 
              onClick={handleDownloadTemplate}
              className="flex items-center space-x-2 px-6 py-3 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-all text-sm"
            >
              <Download size={18} />
              <span>Download Template</span>
            </button>
          </div>

          <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-slate-100">
            <h3 className="text-lg font-bold text-slate-900 mb-4">2. Upload & Process</h3>
            <div className="space-y-4">
              <label className="block w-full aspect-[3/1] border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-emerald-50 hover:border-emerald-300 transition-all group">
                <input type="file" accept=".csv" onChange={e => setFile(e.target.files?.[0] || null)} className="hidden" />
                <Upload className="text-slate-400 group-hover:text-emerald-500 mb-2" size={32} />
                <span className="text-sm font-bold text-slate-500 group-hover:text-emerald-600">
                  {file ? file.name : "Select CSV File"}
                </span>
              </label>

              <button 
                onClick={processFile}
                disabled={!file || loading}
                className="w-full py-4 bg-emerald-600 text-white font-black rounded-xl hover:bg-emerald-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {loading ? <Loader2 className="animate-spin" size={20} /> : <FileText size={20} />}
                <span>Process CSV</span>
              </button>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 text-slate-300 p-8 rounded-[2rem] h-full min-h-[400px] flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-white font-bold">Upload Logs</h3>
            <div className="flex space-x-4 text-xs font-bold">
              <span className="text-emerald-400">Success: {stats.success}</span>
              <span className="text-rose-400">Error: {stats.error}</span>
            </div>
          </div>
          <div className="flex-grow overflow-y-auto space-y-2 font-mono text-xs pr-2 custom-scrollbar">
            {logs.length === 0 && (
              <div className="text-slate-600 text-center mt-20 italic">No logs generated yet...</div>
            )}
            {logs.map((log, idx) => (
              <div key={idx} className={`flex items-start space-x-2 ${log.type === 'success' ? 'text-emerald-400' : 'text-rose-400'}`}>
                {log.type === 'success' ? <CheckCircle size={14} className="mt-0.5 shrink-0" /> : <AlertCircle size={14} className="mt-0.5 shrink-0" />}
                <span>{log.msg}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BulkUpload;
