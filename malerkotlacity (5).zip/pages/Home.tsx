
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../supabase';
import { 
  Zap, 
  ArrowRight, 
  Building2, 
  Phone, 
  MessageSquare, 
  MapPin, 
  Heart,
  ChevronRight,
  Award,
  Search,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { TailSpin } from 'react-loader-spinner';
import { Business } from '../types';
import { updateMeta } from '../utils/seo';

const Home: React.FC = () => {
  const [recent, setRecent] = useState<Business[]>([]);
  const [newlyAdded, setNewlyAdded] = useState<Business[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [stats, setStats] = useState({ total: 0, areas: 0 });
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState('');

  useEffect(() => {
    updateMeta(
      "Malerkotla City - Trusted Local Business Directory",
      "Discover verified local businesses in Malerkotla. Explore shops, services, markets, and expert tailoring in one place."
    );
    
    const fetchData = async () => {
      // Fetch Featured/Top Rated
      const { data: bizData } = await supabase
        .from('businesses')
        .select('*')
        .order('priority', { ascending: false })
        .order('views', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(6);

      // Fetch Newly Added
      const { data: newData } = await supabase
        .from('businesses')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(3);

      const { data: allData } = await supabase
        .from('businesses')
        .select('category, area');

      if (bizData) setRecent(bizData);
      if (newData) setNewlyAdded(newData);
      
      if (allData) {
        const uniqueCats = Array.from(new Set(allData.map(b => b.category)))
          .filter(Boolean)
          .slice(0, 12) as string[];
        const uniqueAreas = new Set(allData.map(b => b.area)).size;
        
        setCategories(uniqueCats);
        setStats({ total: allData.length, areas: uniqueAreas });
      }
      
      setLoading(false);
    };

    fetchData();
  }, []);

  return (
    <div className="bg-white">
      {/* Premium Hero Section with Antigravity Float */}
      <section className="relative min-h-[85vh] flex items-center pt-24 pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-white via-white/40 to-white z-10"></div>
          <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[120%] bg-emerald-50 rounded-full blur-[120px] opacity-60"></div>
        </div>

        <div className="relative z-20 max-w-7xl mx-auto px-6 md:px-12 w-full">
          <div className="max-w-4xl">
            <div className="antigravity-float inline-flex items-center space-x-2 px-4 py-2 bg-emerald-50 rounded-full text-emerald-700 text-[10px] font-black uppercase tracking-widest mb-8 animate-in fade-in slide-in-from-bottom-4">
              <Zap size={14} fill="currentColor" />
              <span>Verified Local Directory</span>
            </div>
            
            <h1 className="text-5xl md:text-8xl font-black text-slate-900 leading-[1.05] mb-8 tracking-tighter animate-in fade-in slide-in-from-bottom-8 duration-700">
              Discover <br />
              Trusted Shops in <br />
              <span className="text-emerald-600">Malerkotla.</span>
            </h1>
            
            <p className="text-lg md:text-2xl text-slate-500 mb-12 max-w-2xl leading-relaxed font-light animate-in fade-in slide-in-from-bottom-12 duration-700 delay-100">
              Your digital gateway to the best tailoring, heritage markets, and local expertise in the city of peace.
            </p>
            
            {/* Wide Search Bar - Antigravity Lift */}
            <div className="antigravity-float-slow flex flex-col md:flex-row gap-4 max-w-3xl animate-in fade-in slide-in-from-bottom-16 duration-700 delay-200">
              <div className="relative flex-grow">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
                <input 
                  type="text" 
                  placeholder="Search by shop name or category..." 
                  className="w-full pl-16 pr-6 py-6 bg-white border border-slate-200 rounded-3xl shadow-2xl shadow-slate-200/50 text-lg font-bold outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (window.location.hash = `#/directory?search=${searchInput}`)}
                />
              </div>
              <Link 
                to={`/directory?search=${searchInput}`}
                className="px-10 py-6 bg-slate-900 text-white font-black rounded-3xl hover:bg-emerald-600 transition-all shadow-xl shadow-slate-200 active-scale flex items-center justify-center whitespace-nowrap"
              >
                Search Directory
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Newly Added Section */}
      {newlyAdded.length > 0 && (
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight">New Arrivals</h2>
                <p className="text-slate-500 mt-2 font-light">The latest businesses to join our community.</p>
              </div>
              <Link to="/directory" className="hidden md:flex items-center text-slate-900 font-black text-xs uppercase tracking-widest hover:text-emerald-600 transition-colors">
                Explore More <ChevronRight size={16} className="ml-1" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {newlyAdded.map(biz => (
                <Link 
                  key={biz.id} 
                  to={`/business/${biz.id}`}
                  className="group bg-slate-50 border border-slate-100 p-6 rounded-[2.5rem] flex items-center gap-6 hover:bg-white hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
                >
                  <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 shadow-sm">
                    <img src={biz.images[0] || 'https://via.placeholder.com/200x200?text=No+Image'} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" alt={biz.business_name} />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock size={12} className="text-emerald-500" />
                      <span className="text-[8px] font-black uppercase tracking-widest text-emerald-600">Newly Listed</span>
                    </div>
                    <h3 className="font-black text-slate-900 text-lg truncate group-hover:text-emerald-600 transition-colors">{biz.business_name}</h3>
                    <div className="flex items-center text-slate-400 text-[10px] font-bold mt-0.5 truncate uppercase tracking-wider">
                      <MapPin size={10} className="mr-1" /> {biz.area}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Section */}
      <section className="py-32 bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row items-end justify-between mb-20 gap-8">
            <div className="max-w-xl">
              <h2 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tight leading-tight">
                Top Rated <br />
                <span className="text-emerald-600">Local Experts.</span>
              </h2>
              <p className="text-slate-500 text-lg mt-6 font-light">Verified businesses providing exceptional service in Malerkotla.</p>
            </div>
            <Link to="/directory" className="group inline-flex items-center px-8 py-4 bg-white border border-slate-200 text-slate-900 font-black rounded-2xl hover:bg-slate-900 hover:text-white transition-all active-scale">
              Explore All
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <TailSpin color="#059669" width={60} />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {recent.map(biz => (
                <article key={biz.id} className="group bg-white rounded-[2.5rem] overflow-hidden border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 flex flex-col h-full">
                  <Link to={`/business/${biz.id}`} className="block relative aspect-[16/10] overflow-hidden">
                    <img src={biz.images[0] || 'https://via.placeholder.com/800x600?text=No+Image'} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={biz.business_name} />
                    <div className="absolute top-6 left-6 flex flex-col gap-2">
                      {biz.priority > 0 && (
                        <div className="px-3 py-1 bg-emerald-600 text-white rounded-xl text-[8px] font-black uppercase tracking-widest flex items-center shadow-lg">
                          <Award size={12} className="mr-1" /> Top Choice
                        </div>
                      )}
                      <span className="px-3 py-1 bg-white/90 backdrop-blur-md rounded-xl text-[8px] font-black text-slate-900 uppercase tracking-widest shadow-sm">
                        {biz.category}
                      </span>
                    </div>
                  </Link>
                  <div className="p-10 flex flex-col flex-grow">
                    <div className="flex-grow">
                      <Link to={`/business/${biz.id}`}>
                        <h3 className="text-2xl font-black text-slate-900 group-hover:text-emerald-600 transition-colors line-clamp-1 mb-2 tracking-tight">{biz.business_name}</h3>
                      </Link>
                      <div className="flex items-center text-slate-400 font-bold text-xs mb-8">
                        <MapPin size={16} className="mr-1.5 text-emerald-500" />
                        {biz.area}, Malerkotla
                      </div>
                    </div>
                    <div className="pt-8 border-t border-slate-50 grid grid-cols-2 gap-3">
                      <a href={`tel:${biz.phone}`} className="flex items-center justify-center py-4 bg-slate-50 hover:bg-emerald-600 text-slate-400 hover:text-white rounded-2xl transition-all">
                        <Phone size={20} />
                      </a>
                      <a href={`https://wa.me/${biz.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center py-4 bg-slate-50 hover:bg-green-600 text-slate-400 hover:text-white rounded-2xl transition-all">
                        <MessageSquare size={20} />
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="bg-slate-900 rounded-[4rem] p-12 md:p-24 text-white relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="relative z-10 max-w-xl text-center md:text-left">
              <h2 className="text-4xl md:text-6xl font-black mb-6 tracking-tight leading-tight">Grow Your <br /> Local Presence.</h2>
              <p className="text-slate-400 text-lg md:text-xl font-light leading-relaxed">List your business for free and get discovered by thousands of customers across Malerkotla.</p>
            </div>
            <div className="relative z-10 flex flex-col sm:flex-row gap-6 w-full md:w-auto">
              <Link to="/register" className="px-12 py-6 bg-emerald-600 text-white font-black rounded-3xl hover:bg-emerald-500 transition-all active-scale text-center shadow-xl shadow-emerald-900/40">
                Register Now
              </Link>
              <Link to="/about" className="px-12 py-6 bg-white/10 backdrop-blur-xl text-white font-black rounded-3xl hover:bg-white/20 transition-all border border-white/10 text-center">
                Learn More
              </Link>
            </div>
            <div className="absolute bottom-[-10%] right-[-5%] w-96 h-96 bg-emerald-500 rounded-full blur-[100px] opacity-20"></div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
