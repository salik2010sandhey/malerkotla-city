
import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase } from '../supabase';
import { Business } from '../types';
import { 
  Phone, 
  MessageSquare, 
  MapPin, 
  Clock, 
  Globe, 
  ArrowLeft, 
  Loader2, 
  CheckCircle2, 
  Share2,
  Building2,
  ExternalLink,
  Award
} from 'lucide-react';
import { updateMeta } from '../utils/seo';

const BusinessDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [business, setBusiness] = useState<Business | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const fetchBusiness = async () => {
      if (!id) return;
      const { data, error } = await supabase
        .from('businesses')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error || !data) {
        setLoading(false);
        return;
      }

      setBusiness(data);
      updateMeta(
        `${data.business_name} in Malerkotla | Local Expert`,
        `Contact ${data.business_name}, a verified ${data.category} in ${data.area}, Malerkotla. View photos, get phone number and directions.`
      );
      setLoading(false);

      // SILENT VIEW INCREMENT
      try {
        const key = `v_${data.id}`;
        if (!localStorage.getItem(key)) {
          await supabase.from('businesses').update({ views: (data.views || 0) + 1 }).eq('id', data.id);
          localStorage.setItem(key, '1');
        }
      } catch(e) {}
    };

    fetchBusiness();
    window.scrollTo(0, 0);
  }, [id]);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: business?.business_name, url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied!');
    }
  };

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center space-y-4">
      <Loader2 className="animate-spin text-emerald-600" size={64} />
      <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest">Opening Profile...</p>
    </div>
  );

  if (!business) return (
    <div className="max-w-4xl mx-auto px-4 py-32 text-center">
      <h2 className="text-4xl font-black text-slate-900 mb-6">Listing Not Found</h2>
      <Link to="/directory" className="inline-flex items-center px-8 py-4 bg-emerald-600 text-white font-bold rounded-2xl active-scale">
        <ArrowLeft size={20} className="mr-2" /> Back to Directory
      </Link>
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Header Bar */}
      <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between border-b border-slate-50">
        <button onClick={() => navigate(-1)} className="p-3 bg-slate-50 text-slate-900 rounded-full hover:bg-slate-100 transition-all">
          <ArrowLeft size={24} />
        </button>
        <button onClick={handleShare} className="p-3 bg-slate-50 text-slate-900 rounded-full hover:bg-slate-100 transition-all">
          <Share2 size={24} />
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 md:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <header className="space-y-6">
              <div className="flex flex-wrap items-center gap-4">
                <span className="px-4 py-1.5 bg-emerald-50 text-emerald-700 text-[10px] font-black uppercase tracking-widest rounded-lg">{business.category}</span>
                <div className="flex items-center text-emerald-600 font-black text-[10px] uppercase tracking-widest">
                  <CheckCircle2 size={16} fill="currentColor" className="text-emerald-50 mr-2" />
                  Verified Directory Member
                </div>
              </div>
              <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter leading-[1.1]">{business.business_name}</h1>
              <div className="flex items-center text-slate-500 text-lg font-bold">
                <MapPin size={24} className="mr-3 text-emerald-500" />
                {business.area}, Malerkotla, Punjab
              </div>
            </header>

            {/* Photo Gallery */}
            <section className="space-y-6">
              <div className="aspect-[16/10] bg-slate-50 rounded-[3rem] overflow-hidden border border-slate-100 shadow-inner">
                <img src={business.images[activeImage] || 'https://via.placeholder.com/1200x800?text=No+Image'} className="w-full h-full object-cover transition-all duration-700" alt={business.business_name} />
              </div>
              {business.images.length > 1 && (
                <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                  {business.images.map((img, idx) => (
                    <button key={idx} onClick={() => setActiveImage(idx)} className={`flex-shrink-0 w-24 h-24 rounded-2xl overflow-hidden border-4 transition-all ${activeImage === idx ? 'border-emerald-500 shadow-xl scale-105' : 'border-white'}`}>
                      <img src={img} className="w-full h-full object-cover" alt="" />
                    </button>
                  ))}
                </div>
              )}
            </section>

            {/* Description */}
            <section className="bg-slate-50 p-10 md:p-16 rounded-[4rem] border border-slate-100">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-8 flex items-center">
                <Building2 size={16} className="mr-3" /> Professional Profile
              </h3>
              <p className="text-slate-600 text-xl md:text-2xl leading-relaxed font-light whitespace-pre-wrap">
                {business.description || "Welcome to " + business.business_name + ". We are proud to serve the community of Malerkotla with our expert services. Please reach out to us via phone or WhatsApp for any inquiries."}
              </p>
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-8">
            <div className="sticky top-32 space-y-8">
              <div className="bg-white border border-slate-100 rounded-[3rem] p-10 shadow-2xl shadow-slate-100 space-y-10">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Business Info</h3>
                
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                      <Clock size={24} />
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-slate-400 uppercase mb-1">Timing</div>
                      <div className="text-lg font-bold text-slate-900">{business.opening_hours}</div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center flex-shrink-0">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-slate-400 uppercase mb-1">Address</div>
                      <div className="text-lg font-bold text-slate-900 leading-snug">{business.address}, {business.area}</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4">
                  <a href={`tel:${business.phone}`} className="flex items-center justify-center w-full py-6 bg-slate-900 text-white font-black rounded-3xl hover:bg-emerald-600 transition-all shadow-xl active-scale">
                    <Phone className="mr-3" size={20} />
                    Call Now
                  </a>
                  <a href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center w-full py-6 bg-emerald-600 text-white font-black rounded-3xl hover:bg-emerald-700 transition-all shadow-xl active-scale">
                    <MessageSquare className="mr-3" size={20} />
                    WhatsApp
                  </a>
                  <a href={business.map_link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center w-full py-6 bg-slate-50 text-slate-900 font-black rounded-3xl hover:bg-slate-100 border border-slate-200 transition-all active-scale">
                    <Globe className="mr-3" size={20} />
                    Get Directions
                  </a>
                </div>
              </div>

              {/* Verified Badge Card */}
              <div className="bg-emerald-600 rounded-[2.5rem] p-10 text-white flex flex-col items-center text-center">
                <Award size={48} className="mb-6" />
                <h4 className="text-2xl font-black mb-4">Trusted Partner</h4>
                <p className="text-emerald-100 text-sm font-light leading-relaxed">This business is a verified member of the official Malerkotla digital directory.</p>
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* Mobile Contact Bar (Fixed) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 p-4 pb-8 pointer-events-none">
        <div className="max-w-md mx-auto bg-slate-900/90 backdrop-blur-2xl p-2 rounded-[2.5rem] flex items-center gap-2 pointer-events-auto border border-white/10 shadow-2xl">
          <a href={`tel:${business.phone}`} className="flex-1 h-16 bg-white/10 text-white rounded-[2rem] flex items-center justify-center font-black uppercase text-xs tracking-widest active:bg-white/20 transition-all">
            <Phone size={20} className="mr-3 text-emerald-400" />
            Call
          </a>
          <a href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noopener noreferrer" className="flex-1 h-16 bg-emerald-600 text-white rounded-[2rem] flex items-center justify-center font-black uppercase text-xs tracking-widest active:bg-emerald-700 transition-all">
            <MessageSquare size={20} className="mr-3" />
            WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};

export default BusinessDetail;
