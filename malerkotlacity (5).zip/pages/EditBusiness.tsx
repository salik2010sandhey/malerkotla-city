import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../App';
import { supabase } from '../supabase';
import { Business } from '../types';
import { Building2, MapPin, Phone, MessageSquare, Clock, Loader2, X, Save, Tag, Upload, Image as ImageIcon } from 'lucide-react';

const EditBusiness = () => {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [business, setBusiness] = useState<Business | null>(null);

  // Image Management State
  const [existingImages, setExistingImages] = useState<string[]>([]);
  const [newFiles, setNewFiles] = useState<File[]>([]);
  const [newPreviews, setNewPreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    business_name: '',
    category: '',
    description: '',
    address: '',
    area: '',
    phone: '',
    whatsapp: '',
    opening_hours: '',
    map_link: ''
  });

  useEffect(() => {
    const fetchBusiness = async () => {
      if (!user || !id) {
        navigate('/dashboard');
        return;
      }
      
      const { data, error } = await supabase
        .from('businesses')
        .select('*')
        .eq('id', id)
        .eq('owner_id', user.id)
        .maybeSingle();

      if (error || !data) {
        navigate('/dashboard');
        return;
      }

      setBusiness(data);
      setExistingImages(data.images || []);
      setFormData({
        business_name: data.business_name,
        category: data.category,
        description: data.description,
        address: data.address,
        area: data.area,
        phone: data.phone,
        whatsapp: data.whatsapp,
        opening_hours: data.opening_hours,
        map_link: data.map_link
      });
      setLoading(false);
    };

    fetchBusiness();
  }, [user, navigate, id]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArr = Array.from(e.target.files) as File[];
      const newUrls = filesArr.map(file => URL.createObjectURL(file));
      
      setNewFiles(prev => [...prev, ...filesArr]);
      setNewPreviews(prev => [...prev, ...newUrls]);
    }
  };

  const removeExistingImage = (index: number) => {
    setExistingImages(prev => prev.filter((_, i) => i !== index));
  };

  const removeNewImage = (index: number) => {
    setNewFiles(prev => prev.filter((_, i) => i !== index));
    setNewPreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !business) return;

    setSaving(true);
    try {
      // 1. Upload new images
      const uploadedUrls: string[] = [];
      for (const file of newFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `business-images/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('business-images')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('business-images')
          .getPublicUrl(filePath);
        
        uploadedUrls.push(publicUrl);
      }

      // 2. Combine with existing (remaining) images
      const finalImages = [...existingImages, ...uploadedUrls];

      // Auto-update map search link on save
      const searchQuery = `${formData.business_name}, ${formData.address}, ${formData.area}, Malerkotla, Punjab`;
      const generatedMapLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(searchQuery)}`;

      const { error } = await supabase
        .from('businesses')
        .update({
          business_name: formData.business_name,
          category: formData.category,
          description: formData.description,
          address: formData.address,
          area: formData.area,
          phone: formData.phone,
          whatsapp: formData.whatsapp,
          opening_hours: formData.opening_hours,
          map_link: generatedMapLink, // Always update link based on current address
          images: finalImages
        })
        .eq('id', business.id);

      if (error) throw error;
      navigate('/dashboard');
    } catch (error: any) {
      alert(error.message || "Failed to update business.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-40 space-y-4">
      <Loader2 className="animate-spin text-emerald-600" size={64} />
      <p className="text-slate-400 font-black uppercase text-xs tracking-widest">Loading Details...</p>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-20">
      <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 p-10 md:p-20 relative overflow-hidden">
        <header className="relative z-10 mb-16 flex items-center justify-between">
          <div>
            <h2 className="text-5xl font-black text-slate-900 mb-4 tracking-tight">Edit Listing</h2>
            <p className="text-slate-500 text-xl font-light">Update your business profile details.</p>
          </div>
          <button onClick={() => navigate('/dashboard')} className="p-4 bg-slate-50 text-slate-400 hover:text-rose-500 rounded-full transition-all">
            <X size={24} />
          </button>
        </header>

        <form onSubmit={handleUpdate} className="relative z-10 space-y-12" aria-busy={saving}>
          
          {/* Image Management Section */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <ImageIcon className="text-emerald-600" size={24} />
              <h3 className="text-lg font-black text-slate-900 uppercase tracking-widest">Business Images</h3>
            </div>
            
            <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
              {/* Grid of Images */}
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-4 mb-6">
                
                {/* Existing Images */}
                {existingImages.map((url, idx) => (
                  <div key={`exist-${idx}`} className="relative aspect-square group">
                    <img src={url} alt="Existing" className="w-full h-full object-cover rounded-2xl border border-slate-200 shadow-sm" />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors rounded-2xl" />
                    <button
                      type="button"
                      onClick={() => removeExistingImage(idx)}
                      className="absolute top-2 right-2 p-1.5 bg-rose-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                      title="Remove Image"
                    >
                      <X size={14} />
                    </button>
                    <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-slate-900/50 text-white text-[9px] font-bold rounded-md backdrop-blur-sm">Saved</span>
                  </div>
                ))}

                {/* New Previews */}
                {newPreviews.map((url, idx) => (
                  <div key={`new-${idx}`} className="relative aspect-square group">
                    <img src={url} alt="New Preview" className="w-full h-full object-cover rounded-2xl border-2 border-emerald-500/50 shadow-sm" />
                    <button
                      type="button"
                      onClick={() => removeNewImage(idx)}
                      className="absolute top-2 right-2 p-1.5 bg-rose-500 text-white rounded-full opacity-100 shadow-lg"
                      title="Remove Upload"
                    >
                      <X size={14} />
                    </button>
                    <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-emerald-600 text-white text-[9px] font-bold rounded-md shadow-sm">New</span>
                  </div>
                ))}

                {/* Upload Button */}
                <label className="aspect-square border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center bg-white hover:bg-emerald-50 hover:border-emerald-400 transition-all cursor-pointer group">
                  <input type="file" accept="image/*" multiple onChange={handleImageChange} className="hidden" />
                  <div className="w-10 h-10 bg-slate-100 group-hover:bg-emerald-100 text-slate-400 group-hover:text-emerald-600 rounded-full flex items-center justify-center mb-2 transition-colors">
                    <Upload size={20} />
                  </div>
                  <span className="text-[10px] font-black text-slate-400 uppercase group-hover:text-emerald-600">Add Images</span>
                </label>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                Tip: You can upload multiple images. Click 'Save Updates' to apply changes.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {/* ... Rest of fields ... */}
            <div className="space-y-2">
              <label htmlFor="edit-name" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Business Name</label>
              <div className="relative">
                <Building2 className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="edit-name" required className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.business_name} onChange={e => setFormData({...formData, business_name: e.target.value})} />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="edit-category" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Category</label>
              <div className="relative">
                <Tag className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="edit-category" required className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} />
              </div>
            </div>

            <div className="md:col-span-2 space-y-2">
              <label htmlFor="edit-desc" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">About the Business</label>
              <textarea id="edit-desc" required className="w-full px-8 py-6 bg-slate-50 border border-slate-200 rounded-[2rem] outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-medium min-h-[150px]" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
            </div>

            <div className="space-y-2">
              <label htmlFor="edit-phone" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="edit-phone" required type="tel" className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="edit-whatsapp" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">WhatsApp No.</label>
              <div className="relative">
                <MessageSquare className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="edit-whatsapp" required type="tel" className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.whatsapp} onChange={e => setFormData({...formData, whatsapp: e.target.value})} />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="edit-hours" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Opening Hours</label>
              <div className="relative">
                <Clock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input id="edit-hours" required className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.opening_hours} onChange={e => setFormData({...formData, opening_hours: e.target.value})} />
              </div>
            </div>

            {/* Simplified Location Section */}
            <div className="md:col-span-2 space-y-8 p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center">
                <MapPin className="mr-2 text-emerald-600" size={18} /> Update Location
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-2">
                  <label htmlFor="edit-area" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Area / Locality</label>
                  <input id="edit-area" required className="w-full px-6 py-5 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold" value={formData.area} onChange={e => setFormData({...formData, area: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-address" className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Full Address</label>
                  <textarea id="edit-address" required className="w-full px-6 py-4 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-bold min-h-[60px]" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
                </div>
              </div>
            </div>
          </div>

          <button type="submit" disabled={saving} className="w-full py-6 bg-slate-900 text-white font-black text-xl rounded-3xl hover:bg-slate-800 transition-all flex items-center justify-center space-x-3 shadow-2xl shadow-slate-900/20 disabled:opacity-70 group">
            {saving ? <Loader2 className="animate-spin" size={24} /> : (
              <>
                <Save size={24} />
                <span>Save Updates</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default EditBusiness;