
import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../App';
import { supabase } from '../supabase';
import { Business } from '../types';
import { Building2, Plus, Loader2, MapPin, Eye, Edit3, Upload, Trash2 } from 'lucide-react';

const SPECIAL_EMAIL = 'adminmalerkotla@gmail.com';

const OwnerDashboard = () => {
  const { user } = useAuth();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMyBusinesses = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('businesses')
      .select('*')
      .eq('owner_id', user.id)
      .order('created_at', { ascending: false });
    
    if (data) setBusinesses(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchMyBusinesses();
  }, [user]);

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to remove "${name}" permanently?`)) return;
    const { error } = await supabase.from('businesses').delete().eq('id', id);
    if (!error) fetchMyBusinesses();
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="animate-spin text-emerald-600" size={64} />
    </div>
  );

  const canAddMore = user?.email === SPECIAL_EMAIL || businesses.length === 0;

  return (
    <div className="max-w-7xl mx-auto px-6 py-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-10 mb-20">
        <div>
          <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-6 tracking-tighter">My Listings</h1>
          <p className="text-slate-500 text-xl font-light">Manage your verified presence in Malerkotla.</p>
        </div>
        <div className="flex flex-wrap gap-4">
          <Link to="/bulk-upload" className="px-8 py-5 bg-slate-50 text-slate-700 font-bold rounded-2xl hover:bg-slate-100 transition-all border border-slate-200 text-sm flex items-center">
            <Upload size={20} className="mr-3" />
            Bulk Upload
          </Link>
          {canAddMore && (
            <Link to="/add-business" className="px-10 py-5 bg-emerald-600 text-white font-black rounded-2xl hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-900/20 text-sm flex items-center">
              <Plus size={24} className="mr-3" />
              Add Business
            </Link>
          )}
        </div>
      </div>

      {businesses.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {businesses.map(biz => (
            <div key={biz.id} className="bg-white rounded-[3rem] border border-slate-100 shadow-xl overflow-hidden flex flex-col group animate-in fade-in slide-in-from-bottom-4">
              <div className="aspect-[16/8] relative overflow-hidden">
                <img src={biz.images[0] || 'https://via.placeholder.com/800x400?text=No+Image'} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={biz.business_name} />
                <div className="absolute top-6 left-6 px-4 py-2 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg">Verified & Live</div>
              </div>
              <div className="p-10 flex flex-col flex-grow">
                <div className="flex-grow">
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-2 block">{biz.category}</span>
                  <h3 className="text-3xl font-black text-slate-900 mb-3 tracking-tight">{biz.business_name}</h3>
                  <div className="flex items-center text-slate-400 font-bold text-sm mb-8">
                    <MapPin size={18} className="mr-2 text-emerald-500" /> 
                    {biz.area}, Malerkotla
                  </div>
                </div>

                <div className="pt-8 border-t border-slate-50 grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Link to={`/business/${biz.id}`} className="h-14 flex items-center justify-center bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-600 transition-all">
                    <Eye size={16} className="mr-2" /> View
                  </Link>
                  <Link to={`/edit-business/${biz.id}`} className="h-14 flex items-center justify-center bg-emerald-50 text-emerald-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-100 transition-all border border-emerald-100">
                    <Edit3 size={16} className="mr-2" /> Edit
                  </Link>
                  <button onClick={() => handleDelete(biz.id, biz.business_name)} className="h-14 flex items-center justify-center bg-rose-50 text-rose-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all border border-rose-100 col-span-2 md:col-span-2">
                    <Trash2 size={16} className="mr-2" /> Remove Listing
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-50 p-24 rounded-[4rem] text-center border-2 border-dashed border-slate-200">
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-sm text-slate-200">
            <Building2 size={48} />
          </div>
          <h3 className="text-3xl font-black text-slate-900 mb-4">No Listings Yet</h3>
          <p className="text-slate-500 text-xl mb-12 max-w-md mx-auto font-light">Start your digital journey by adding your shop to Malerkotla's official directory.</p>
          <Link to="/add-business" className="inline-flex items-center px-12 py-6 bg-emerald-600 text-white font-black rounded-[2rem] shadow-2xl shadow-emerald-900/20 active-scale">
            <Plus size={24} className="mr-3" />
            Register My Business
          </Link>
        </div>
      )}
    </div>
  );
};

export default OwnerDashboard;
