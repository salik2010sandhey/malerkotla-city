
import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';
import { Business } from '../types';
import { 
  ShieldCheck, CheckCircle, Trash2, LayoutDashboard, Clock, 
  CheckCircle2, Star, Eye, X, Loader2, Search, Filter, MapPin
} from 'lucide-react';

type AdminTab = 'DASHBOARD' | 'PENDING' | 'APPROVED' | 'FEATURED';

const AdminDashboard: React.FC = () => {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<AdminTab>('DASHBOARD');
  const [search, setSearch] = useState('');
  const [selectedBiz, setSelectedBiz] = useState<Business | null>(null);

  const fetchAll = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('businesses')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) setBusinesses(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleDelete = async (bizId: string) => {
    if (!confirm("Delete this listing permanently?")) return;
    const { error } = await supabase.from('businesses').delete().eq('id', bizId);
    if (!error) fetchAll();
  };

  const toggleFeatured = async (bizId: string, current: boolean) => {
    const { error } = await supabase.from('businesses').update({ is_featured: !current }).eq('id', bizId);
    if (!error) fetchAll();
  };

  const toggleApproved = async (bizId: string, current: boolean) => {
    const { error } = await supabase.from('businesses').update({ is_approved: !current }).eq('id', bizId);
    if (!error) fetchAll();
  };

  const stats = {
    total: businesses.length,
    pending: businesses.filter(b => !b.is_approved).length,
    approved: businesses.filter(b => b.is_approved).length,
    featured: businesses.filter(b => b.is_featured).length,
  };

  const filtered = businesses.filter(b => {
    const matchesSearch = b.business_name.toLowerCase().includes(search.toLowerCase());
    if (activeTab === 'PENDING') return matchesSearch && !b.is_approved;
    if (activeTab === 'APPROVED') return matchesSearch && b.is_approved;
    if (activeTab === 'FEATURED') return matchesSearch && b.is_featured;
    return matchesSearch;
  });

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center space-y-4">
      <Loader2 className="animate-spin text-emerald-600" size={48} />
      <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">Loading Panel...</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50/50 p-6 md:p-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-8">
          <div>
            <div className="inline-flex items-center space-x-2 bg-slate-900 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest mb-4">
              <ShieldCheck size={14} />
              <span>System Administrator</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter">Control Center</h1>
          </div>
          <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
            {(['DASHBOARD', 'PENDING', 'APPROVED', 'FEATURED'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-900'}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {activeTab === 'DASHBOARD' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard label="Total" value={stats.total} IconComponent={LayoutDashboard} color="blue" />
            <StatCard label="Pending" value={stats.pending} IconComponent={Clock} color="amber" pulse={stats.pending > 0} />
            <StatCard label="Verified" value={stats.approved} IconComponent={CheckCircle2} color="emerald" />
            <StatCard label="Featured" value={stats.featured} IconComponent={Star} color="rose" />
          </div>
        ) : (
          <div className="space-y-8">
            <div className="relative">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="text" 
                placeholder="Search database..." 
                className="w-full pl-14 pr-6 py-5 bg-white border border-slate-200 rounded-[1.5rem] outline-none shadow-sm focus:ring-4 focus:ring-emerald-500/5 transition-all"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            
            <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50/50">
                    <tr>
                      <th className="px-10 py-6 text-[10px] font-black uppercase text-slate-400">Business Listing</th>
                      <th className="px-10 py-6 text-[10px] font-black uppercase text-slate-400">Contact</th>
                      <th className="px-10 py-6 text-[10px] font-black uppercase text-slate-400">Status</th>
                      <th className="px-10 py-6 text-[10px] font-black uppercase text-slate-400 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filtered.map(biz => (
                      <tr key={biz.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-10 py-6">
                          <div className="flex items-center space-x-6">
                            <img src={biz.images[0]} className="w-16 h-16 rounded-2xl object-cover shadow-sm" alt="" />
                            <div>
                              <div className="font-black text-slate-900 text-lg leading-tight">{biz.business_name}</div>
                              <div className="text-[10px] font-bold text-slate-400 uppercase mt-1">{biz.category}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-10 py-6">
                          <div className="text-sm font-bold text-slate-600">{biz.phone}</div>
                          <div className="text-xs text-slate-400">{biz.area}</div>
                        </td>
                        <td className="px-10 py-6">
                          <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase ${biz.is_approved ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-amber-50 text-amber-600 border border-amber-100'}`}>
                            {biz.is_approved ? 'Verified' : 'Pending'}
                          </span>
                        </td>
                        <td className="px-10 py-6">
                          <div className="flex items-center justify-center space-x-3">
                            <button onClick={() => setSelectedBiz(biz)} className="p-3 bg-slate-100 text-slate-500 rounded-xl hover:bg-slate-900 hover:text-white transition-all"><Eye size={18} /></button>
                            <button onClick={() => toggleApproved(biz.id, biz.is_approved)} className={`p-3 rounded-xl transition-all ${biz.is_approved ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}><CheckCircle size={18} /></button>
                            <button onClick={() => toggleFeatured(biz.id, biz.is_featured)} className={`p-3 rounded-xl transition-all ${biz.is_featured ? 'bg-rose-500 text-white' : 'bg-slate-100 text-slate-400'}`}><Star size={18} /></button>
                            <button onClick={() => handleDelete(biz.id)} className="p-3 bg-rose-50 text-rose-400 rounded-xl hover:bg-rose-500 hover:text-white transition-all"><Trash2 size={18} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {selectedBiz && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={() => setSelectedBiz(null)}></div>
            <div className="relative bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[3rem] p-8 md:p-12 shadow-2xl">
              <button onClick={() => setSelectedBiz(null)} className="absolute top-8 right-8 p-3 bg-slate-100 rounded-full hover:bg-rose-50 hover:text-rose-500 transition-all"><X size={24} /></button>
              <h2 className="text-4xl font-black text-slate-900 mb-8 tracking-tighter">{selectedBiz.business_name}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <img src={selectedBiz.images[0]} className="w-full aspect-[16/10] object-cover rounded-[2rem] shadow-xl" alt="" />
                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Description</label>
                    <p className="text-slate-600 leading-relaxed">{selectedBiz.description}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Contact</label>
                      <p className="font-bold text-slate-900">{selectedBiz.phone}</p>
                    </div>
                    <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Area</label>
                      <p className="font-bold text-slate-900">{selectedBiz.area}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const StatCard = ({ label, value, IconComponent, color, pulse }: any) => {
  const colorMap: any = { 
    blue: 'bg-blue-50 text-blue-600', 
    amber: 'bg-amber-50 text-amber-600', 
    emerald: 'bg-emerald-50 text-emerald-600', 
    rose: 'bg-rose-50 text-rose-600' 
  };
  
  return (
    <div className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/40 relative overflow-hidden group hover:-translate-y-1 transition-all">
      {pulse && <div className="absolute top-6 right-6 w-2.5 h-2.5 bg-amber-500 rounded-full animate-ping"></div>}
      <div className={`w-16 h-16 rounded-2xl ${colorMap[color]} flex items-center justify-center mb-8 group-hover:scale-110 transition-transform`}>
        <IconComponent size={32} />
      </div>
      <div className="text-5xl font-black text-slate-900 mb-2 tracking-tighter">{value}</div>
      <div className="text-[11px] font-black text-slate-400 uppercase tracking-widest">{label}</div>
    </div>
  );
};

export default AdminDashboard;
